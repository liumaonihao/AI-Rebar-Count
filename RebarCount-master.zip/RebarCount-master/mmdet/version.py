# GENERATED VERSION FILE
# TIME: Tue Jan 15 10:13:29 2019

__version__ = '0.5.5+a8ec6fb'
short_version = '0.5.5'
